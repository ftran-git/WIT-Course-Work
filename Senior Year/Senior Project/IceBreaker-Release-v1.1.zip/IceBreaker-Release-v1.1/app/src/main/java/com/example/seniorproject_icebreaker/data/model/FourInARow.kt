package com.example.seniorproject_icebreaker.data.model
enum class FourInARowColor(val value: String) {
    RED("Red"),
    YELLOW("Yellow");

    override fun toString(): String {
        return value
    }
}
