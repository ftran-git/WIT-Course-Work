package com.example.seniorproject_icebreaker.data.model
enum class TicTacToeMark(val value: String) {
    X("X"),
    O("O");

    override fun toString(): String {
        return value
    }
}
